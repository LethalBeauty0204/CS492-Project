# CS492-Project
Group 5 Team Project

Product Description 1: Bookstore Management System 
You have been approached by the owner of a rare bookstore to provide an automated accounting, inventory, ordering, and sales system. The bookstore system will streamline the store’s business processes. With this system, the customers’ current paper-based process will be replaced with a computer-based system. The entire inventory process, from the moment the books are entered into the system to when they are purchased, will be greatly sped up. The main system capabilities include the following: 
 Keeping track of inventory 
 Keeping track of sales records 
 Providing the ability to place orders to manufacturers 
 Providing the ability for customers to place orders Order
