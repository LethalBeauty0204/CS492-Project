document.addEventListener('DOMContentLoaded', function () {
    const cartTab = document.querySelector('.cartTab');
    cartTab.style.right = '-400px'; // Ensure it starts hidden
    initApp();
    document.querySelectorAll('.addCart').forEach(button => {
        button.addEventListener('click', function () {
            this.classList.add('clicked');
            setTimeout(() => {
                this.classList.remove('clicked');
            }, 400); // Adjust timing as necessary
        });
    });
});

let products = [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];

function initApp() {
    fetch('/books')
    .then(response => response.json())
    .then(data => {
        products = data;
        renderProducts();
        updateCart();
    })
    .catch(error => console.error('Error loading books:', error));
}

function renderProducts() {
    const container = document.querySelector('.listProduct');
    container.innerHTML = '';  // Clear previous contents
    products.forEach(product => {
        const sanitizedTitle = product.title.replace(/\s+/g, '_'); // Replace spaces with underscores for the URL
        const imagePath = product.image || `images/${sanitizedTitle}.png`; // Assumes images are stored in an 'images' folder
        const html = `
            <div class="item" data-id="${product.id}">
                <img src="books/images/${product.title}.png" alt="${product.title}" />
                <h2><a href="/books/${sanitizedTitle}.html">${product.title}</a></h2>
                <p>$${product.price.toFixed(2)}</p>
                <button onclick="addToCart(${product.id})">Add To Cart</button>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', html);
    });
}

function addToCart(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;

    const itemIndex = cart.findIndex(item => item.id === id);
    if (itemIndex > -1) {
        cart[itemIndex].quantity++;
    } else {
        const cartItem = {...product, quantity: 1};
        cart.push(cartItem);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}

function updateCart() {
    const cartContainer = document.querySelector('.listCart');
    cartContainer.innerHTML = '';  // Clear previous contents

    let totalAmount = 0; // Initialize total amount

    cart.forEach(item => {
        const cartHtml = `
            <div class="cart-item" data-id="${item.id}">
                <img src="${item.image || 'placeholder.png'}" alt="${item.title}">
                <p>${item.title}</p>
                <p>Quantity: ${item.quantity}</p>
                <p>Total: $${(item.quantity * item.price).toFixed(2)}</p>
                <button onclick="changeQuantity(${item.id}, 'minus')">-</button>
                <button onclick="changeQuantity(${item.id}, 'plus')">+</button>
                <button onclick="removeItem(${item.id})">Remove</button>
            </div>
        `;
        cartContainer.insertAdjacentHTML('beforeend', cartHtml);

        totalAmount += item.quantity * item.price; // Update total amount
    });

    // Display the total amount in the cart
    const totalDisplay = document.querySelector('.cart-total');
    if (!totalDisplay) {
        const totalElement = document.createElement('p');
        totalElement.className = 'cart-total';
        totalElement.textContent = `Total: $${totalAmount.toFixed(2)}`;
        cartContainer.appendChild(totalElement);
    } else {
        totalDisplay.textContent = `Total: $${totalAmount.toFixed(2)}`;
    }

    const iconCartSpan = document.querySelector('.icon-cart span');
    iconCartSpan.textContent = cart.reduce((acc, item) => acc + item.quantity, 0);  // Update cart quantity icon
}


function changeQuantity(id, action) {
    const index = cart.findIndex(item => item.id === id);
    if (index === -1) return;

    if (action === 'plus') {
        cart[index].quantity++;
    } else if (action === 'minus') {
        cart[index].quantity--;
        if (cart[index].quantity < 1) {
            cart.splice(index, 1);  // Remove item from cart if quantity is zero
        }
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}

function removeItem(id) {
    cart = cart.filter(item => item.id !== id);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}

function toggleCartVisibility() {
    const cartTab = document.querySelector('.cartTab');
    if (cartTab.style.right === '0px') {
        cartTab.style.right = '-400px'; // Slide out
    } else {
        cartTab.style.right = '0px'; // Slide in
    }
}
function closeCart() {
    const cartTab = document.querySelector('.cartTab');
    cartTab.style.right = '-400px'; // Slide out
}
