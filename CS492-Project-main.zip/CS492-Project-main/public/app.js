document.addEventListener('DOMContentLoaded', function() {
    initApp();
});

let products = [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];

function initApp() {
    fetch('/books')
    .then(response => response.json())
    .then(data => {
        products = data;
        renderProducts();
        updateCart();
    })
    .catch(error => console.error('Error loading books:', error));
}

function renderProducts() {
    const container = document.querySelector('.listProduct');
    container.innerHTML = '';  // Clear previous contents
    products.forEach(product => {
        const html = `
            <div class="item" data-id="${product.id}">
                <img src="${product.image || 'placeholder.png'}" alt="${product.title}">
                <h2>${product.title}</h2>
                <p>$${product.price.toFixed(2)}</p>
                <button onclick="addToCart(${product.id})">Add To Cart</button>
            </div>
        `;
        container.insertAdjacentHTML('beforeend', html);
    });
}

function addToCart(id) {
    const product = products.find(p => p.id === id);
    if (!product) return;

    const itemIndex = cart.findIndex(item => item.id === id);
    if (itemIndex > -1) {
        cart[itemIndex].quantity++;
    } else {
        const cartItem = {...product, quantity: 1};
        cart.push(cartItem);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}

function updateCart() {
    const cartContainer = document.querySelector('.listCart');
    cartContainer.innerHTML = '';  // Clear previous contents
    cart.forEach(item => {
        const cartHtml = `
            <div class="cart-item" data-id="${item.id}">
                <img src="${item.image || 'placeholder.png'}" alt="${item.title}">
                <p>${item.title}</p>
                <p>Quantity: ${item.quantity}</p>
                <p>Total: $${(item.quantity * item.price).toFixed(2)}</p>
                <button onclick="changeQuantity(${item.id}, 'minus')">-</button>
                <button onclick="changeQuantity(${item.id}, 'plus')">+</button>
                <button onclick="removeItem(${item.id})">Remove</button>
            </div>
        `;
        cartContainer.insertAdjacentHTML('beforeend', cartHtml);
    });

    const iconCartSpan = document.querySelector('.icon-cart span');
    iconCartSpan.textContent = cart.reduce((acc, item) => acc + item.quantity, 0);  // Update cart quantity icon
}

function changeQuantity(id, action) {
    const index = cart.findIndex(item => item.id === id);
    if (index === -1) return;

    if (action === 'plus') {
        cart[index].quantity++;
    } else if (action === 'minus') {
        cart[index].quantity--;
        if (cart[index].quantity < 1) {
            cart.splice(index, 1);  // Remove item from cart if quantity is zero
        }
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}

function removeItem(id) {
    cart = cart.filter(item => item.id !== id);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}

function toggleCartVisibility() {
    const cartTab = document.querySelector('.cartTab');
    cartTab.style.display = cartTab.style.display === 'block' ? 'none' : 'block';
}
