let listProductHTML = document.querySelector('.listProduct');
let listCartHTML = document.querySelector('.listCart');
let iconCart = document.querySelector('.icon-cart');
let iconCartSpan = document.querySelector('.icon-cart span');
let body = document.querySelector('body');
let closeCart = document.querySelector('.close');
let products = [];
let cart = [];
let totalPrice = 0

iconCart.addEventListener('click', () => {
    body.classList.toggle('showCart');
})
closeCart.addEventListener('click', () => {
    body.classList.toggle('showCart');
})

    const addDataToHTML = () => {
    // remove datas default from HTML

        listProductHTML.innerHTML = '';
        if(products.length > 0) // if has data
        {
            products.forEach(product => {
                let newProduct = document.createElement('div');
                newProduct.dataset.id = product.id;
                newProduct.classList.add('item');
                newProduct.innerHTML = 
                `<img src="${product.image}" alt="">
                <h2>${product.name}</h2>
                <div class="price">$${product.price}</div>
                <button class="addCart">Add To Cart</button>`;
                listProductHTML.appendChild(newProduct);
            });
        }
    }
    listProductHTML.addEventListener('click', (event) => {
        let positionClick = event.target;
        if(positionClick.classList.contains('addCart')){
            let id_product = positionClick.parentElement.dataset.id;
            addToCart(id_product);
        }
    })
const addToCart = (product_id) => {
    let productIndex = products.findIndex(p => p.id == product_id);
    if (productIndex === -1) return;  // Check if product exists
    let product = products[productIndex];

    let cartIndex = cart.findIndex(item => item.product_id == product_id);
    if (cartIndex < 0) {  // Product not in cart
        cart.push({
            product_id: product_id,
            quantity: 1,
            price: parseFloat(product.price)  // Convert price to float
        });
        totalPrice += parseFloat(product.price);  // Ensure adding a number
    } else {  // Product already in cart
        cart[cartIndex].quantity++;
        totalPrice += parseFloat(product.price);  // Ensure adding a number
    }
    addCartToHTML();
    addCartToMemory();
}


const addCartToMemory = () => {
    localStorage.setItem('cart', JSON.stringify(cart));
}
const addCartToHTML = () => {
    listCartHTML.innerHTML = '';
    let totalQuantity = 0;
    if (cart.length > 0) {
        cart.forEach(item => {
            totalQuantity += item.quantity;
            let newItem = document.createElement('div');
            newItem.classList.add('item');
            newItem.dataset.id = item.product_id;

            let positionProduct = products.findIndex((value) => value.id == item.product_id);
            let info = products[positionProduct];
            listCartHTML.appendChild(newItem);
            newItem.innerHTML = `
                <div class="image">
                    <img src="${info.image}" alt="">
                </div>
                <div class="name">${info.name}</div>
                <div class="totalPrice">$${info.price * item.quantity}</div>
                <div class="quantity">
                    <span class="minus"><</span>
                    <span>${item.quantity}</span>
                    <span class="plus">></span>
                </div>
            `;
        });
    }
    // Display total price
    let totalPriceElement = document.createElement('div');
    totalPriceElement.textContent = 'Total Price: $' + totalPrice;
    listCartHTML.appendChild(totalPriceElement);
    iconCartSpan.innerText = totalQuantity; // Update the total number of items
}


listCartHTML.addEventListener('click', (event) => {
    let positionClick = event.target;
    if(positionClick.classList.contains('minus') || positionClick.classList.contains('plus')){
        let product_id = positionClick.parentElement.parentElement.dataset.id;
        let type = 'minus';
        if(positionClick.classList.contains('plus')){
            type = 'plus';
        }
        changeQuantityCart(product_id, type);
    }
})
const changeQuantityCart = (product_id, type) => {
    let positionItemInCart = cart.findIndex((value) => value.product_id == product_id);
    if (positionItemInCart >= 0) {
        let item = cart[positionItemInCart];
        switch (type) {
            case 'plus':
                item.quantity += 1;
                totalPrice += item.price;
                break;
            case 'minus':
                if (item.quantity > 1) {
                    item.quantity -= 1;
                    totalPrice -= item.price;
                } else {
                    totalPrice -= item.price;
                    cart.splice(positionItemInCart, 1); // Remove the item completely if quantity is 0
                }
                break;
        }
        addCartToHTML();
        addCartToMemory();
    }
}


const initApp = () => {
    // get data product
    fetch('/books')
    .then(response => response.json())
    .then(data => {
        products = data;
        addDataToHTML();

        // get data cart from memory
        if(localStorage.getItem('cart')){
            cart = JSON.parse(localStorage.getItem('cart'));
            addCartToHTML();
        }
    })
}
initApp();