document.addEventListener('DOMContentLoaded', function() {
    const changePasswordForm = document.getElementById('changePasswordForm');
    const errorMessage = document.getElementById('errorMessage');

    changePasswordForm.onsubmit = function(e) {
        e.preventDefault();

        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword !== confirmPassword) {
            errorMessage.textContent = 'Passwords do not match.';
            errorMessage.style.display = 'block';
            return;
        }

        // Prepare the data for sending
        const data = {
            username: 'admin', // Only for the one user
            newPassword: newPassword
        };

        // Make the Fetch request to change the password
        fetch('/change-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Password change failed.');
            }
            return response.text();
        })
        .then(() => {
            alert('Password changed successfully.');
            window.location.href = 'login.html';
        })
        .catch(error => {
            console.error('Error:', error);
            errorMessage.textContent = error.toString();
            errorMessage.style.display = 'block';
        });
    };
});
