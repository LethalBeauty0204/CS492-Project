document.addEventListener('DOMContentLoaded', function() {
    fetchBooks();
});

function fetchBooks() {
    fetch('/books')
    .then(response => response.json())
    .then(books => {
        const booksList = document.getElementById('booksList');
        booksList.innerHTML = ''; // Clear existing entries
        books.forEach(book => {
            const bookEntry = document.createElement('div');
            bookEntry.className = 'book-entry';
            bookEntry.setAttribute('data-id', book.id); // Set the data-id attribute for each book entry
            bookEntry.innerHTML = `
                <div class="book-details">
                    <h3>Editing: ${book.title}</h3>
                    <label>Title:<input type="text" value="${book.title}" class="book-title"></label>
                    <label>Author:<input type="text" value="${book.author}" class="book-author"></label>
                    <label>Price:<input type="number" step="0.01" value="${book.price}" class="book-price"></label>
                    <label>Description:<textarea class="book-description">${book.description || ''}</textarea></label>
                    <button onclick="updateBook(${book.id})">Save Changes</button>
                </div>
            `;
            booksList.appendChild(bookEntry);
        });
    })
    .catch(error => console.error('Error fetching books:', error));
}

function updateBook(bookId) {
    const bookEntry = document.querySelector(`.book-entry[data-id="${bookId}"]`);
    const title = bookEntry.querySelector('.book-title').value;
    const author = bookEntry.querySelector('.book-author').value;
    const price = parseFloat(bookEntry.querySelector('.book-price').value);
    const description = bookEntry.querySelector('.book-description').value;

    fetch(`/update-book/${bookId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, author, price, description }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok.');
        }
        return response.json();
    })
    .then(() => {
        alert('Book updated successfully.');
        fetchBooks(); // Refresh the list to reflect the updated information
    })
    .catch(error => {
        console.error('Error updating book:', error);
        alert('Failed to update book.');
    });
}
