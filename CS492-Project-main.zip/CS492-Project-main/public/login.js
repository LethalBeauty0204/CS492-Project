document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent the default form submission

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        })
        .then(response => {
            if (response.status === 403) {
                // Server indicates it's time for a password change
                alert("Your password needs to be changed.");
                window.location.href = 'changePassword.html'; // Redirect to change password page
                return null; // Since we're redirecting, no need to process further
            } else if (!response.ok) {
                // Handle other non-OK responses, potentially parsing error messages
                return response.json().then(data => {
                    throw new Error(data.message || 'Login failed');
                });
            }
            return response.json(); // Proceed to parse the response as JSON only if response is OK
        })
        .then(data => {
            // This block will now only execute for successful logins
            if (data) {
                console.log(data.message); // Log the success message
                localStorage.setItem('loginTime', Date.now().toString());
                window.location.href = 'admin.html';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert(error.message); // Display any caught errors to the user
        });
    });
});
