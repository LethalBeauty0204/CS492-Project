document.addEventListener('DOMContentLoaded', function() {
    const loginTime = localStorage.getItem('loginTime');
    const currentTime = Date.now();

    if (loginTime && currentTime - parseInt(loginTime) > 7776000000 ) { // 90 days in milliseconds for now.
        window.location.href = 'changePassword.html';
    }

    const logoutButton = document.getElementById('logoutButton'); // Assuming you have a logout button
    if (logoutButton) {
        logoutButton.addEventListener('click', function() {
            localStorage.removeItem('loginTime'); // Clear login time on logout
            // Redirect to login page or perform other logout actions
            window.location.href = 'login.html';
        });
    }
});
