const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const saltRounds = 10;
const { saveBookPageToFile } = require('./bookPageGenerator');
const { saveReceiptToFile } = require('./receiptPageGenerator');


const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Initialize book database
const dbPath = path.join(__dirname, '..', 'mydb.db');
const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
  if (err) {
    console.error('Error opening book database', err.message);
  } else {
    console.log('Connected to the book database.');
    db.run('CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, price REAL)', (err) => {
      if (err) {
        console.error('Error creating books table', err.message);
      }
    });
  }
});

// Initialize user authentication database
const userAuthDbPath = path.join(__dirname, '..', 'userAuth.db');
const userAuthDb = new sqlite3.Database(userAuthDbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
  if (err) {
    console.error('Error opening user authentication database', err.message);
  } else {
    console.log('Connected to the user authentication database.');
    userAuthDb.run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, hashedPassword TEXT, passwordChangeDate TEXT)`, (err) => {
      if (err) {
        console.error('Error creating users table', err.message);
      } else {
        console.log('Users table is ready.');
        // Initialize default admin user
        const defaultUsername = 'admin';
        bcrypt.hash('admin', saltRounds, (err, hash) => {
          if (err) {
            console.error('Error hashing password:', err);
          } else {
            userAuthDb.run(`INSERT OR IGNORE INTO users (username, hashedPassword, passwordChangeDate) VALUES ('admin', ?, datetime('now'))`, [hash], err => {
              if (err) console.error('Error inserting admin user:', err.message);
              else console.log('Admin user inserted successfully.');
            });
          }
        });        
      }
    });
  }
});


// Serve individual book pages
app.get('/books/:id', (req, res) => {
  const bookId = req.params.id;
  res.sendFile(path.join(__dirname, '..', 'public', 'books', `${bookId}.html`));
});

// add-book endpoint w/ file creation
app.post('/add-book', (req, res) => {
  const { title, author, price, description = '' } = req.body; // Assume description might be optional
  db.run(`INSERT INTO books (title, author, price, description) VALUES (?, ?, ?, ?)`, [title, author, price, description], function(err) {
    if (err) {
      res.status(500).send(err.message);
    } else {
      const book = { id: this.lastID, title, author, price, description };
      saveBookPageToFile(book); // Now correctly passes a book object
      res.json({ id: this.lastID });
    }
  });
});



// Fetch all books endpoint
app.get('/books', (req, res) => {
  db.all("SELECT * FROM books", [], (err, rows) => {
    if (err) {
      res.status(500).send(err.message);
    } else {
      res.json(rows);
    }
  });
});

// Delete book endpoint
app.delete('/delete-book/:id', (req, res) => {
  const { id } = req.params;
  db.run(`DELETE FROM books WHERE id = ?`, id, function(err) {
    if (err) {
      res.status(500).send(err.message);
    } else {
      res.json({ success: true, message: `Book with ID ${id} deleted` });
    }
  });
});

app.post('/update-book/:id', (req, res) => {
  const { id } = req.params;
  const { title, author, price, description } = req.body;
  
  const sql = `UPDATE books SET title = ?, author = ?, price = ?, description = ? WHERE id = ?`;
  const params = [title, author, price, description, id];
  
  db.run(sql, params, function(err) {
      if (err) {
          res.status(500).send({error: err.message});
          return;
      }

      // Fetch the updated book details to ensure we have the latest information
      db.get(`SELECT * FROM books WHERE id = ?`, [id], (err, book) => {
          if (err) {
              res.status(500).send({error: err.message});
              return;
          }
          if (book.description) { // Check if the book has a description after fetching updated data
              saveBookPageToFile(book); // This function now expects a complete book object
          }
          res.json({
              message: "Success",
              data: book, // Send back the updated book data
              changes: this.changes
          });
      });
  });
});
// Password Change Endpoint
app.post('/change-password', async (req, res) => {
  const { username, newPassword } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
    userAuthDb.run(`UPDATE users SET hashedPassword = ?, passwordChangeDate = datetime('now') WHERE username = ?`, [hashedPassword, username], function(err) {
      if (err) {
        return res.status(500).send('Error updating password.');
      }
      if (this.changes > 0) {
        res.send('Password updated successfully.');
      } else {
        res.status(404).send('User not found.');
      }
    });
  } catch (err) {
    res.status(500).send('Server error.');
  }
});

// Login Endpoint
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  userAuthDb.get(`SELECT * FROM users WHERE username = ?`, [username], (err, user) => {
      if (err || !user) {
          return res.status(401).send('Authentication failed.');
      }

      const lastPasswordChange = new Date(user.passwordChangeDate);
      const now = new Date();
      const daysSinceLastChange = (new Date() - new Date(lastPasswordChange)) / (1000 * 60 * 60 * 24);

      if (daysSinceLastChange > 90) {
          // Inform the user that a password change is required
          return res.status(403).json({ message: "Password change required" });
      }

      bcrypt.compare(password, user.hashedPassword, (err, result) => {
          if (result) {
              // Proceed with login
              res.json({ message: "Login successful." });
          } else {
            res.status(401).json({ message: "Authentication failed." });
          }
      });
  });
});

// POST endpoint to create a receipt
app.post('/create-receipt', (req, res) => {
  const { items, name, street, city, state, postalCode, email } = req.body;
  const receiptNumber = getNextReceiptNumber();  // Get the next receipt number
  const templatePath = path.join(__dirname, '..', 'templates', 'receiptTemplate.html');
  const receiptPath = path.join(__dirname, 'public', 'receipts', `receipt(${receiptNumber}).html`);

  fs.readFile(templatePath, 'utf8', (err, template) => {
      if (err) {
          console.error('Error reading receipt template:', err);
          return res.sendStatus(500);
      }

      let receiptContent = template.replace('{{itemsPlaceholder}}', items)
                                   .replace('{{namePlaceholder}}', name)
                                   .replace('{{streetPlaceholder}}', street)
                                   .replace('{{cityPlaceholder}}', city)
                                   .replace('{{statePlaceholder}}', state)
                                   .replace('{{postalPlaceholder}}', postalCode)
                                   .replace('{{emailPlaceholder}}', email);

      fs.writeFile(receiptPath, receiptContent, 'utf8', (err) => {
          if (err) {
              console.error('Failed to write receipt file:', err);
              return res.sendStatus(500);
          }
          res.redirect(`/receipts/receipt(${receiptNumber}).html`);
      });
  });
});

function getNextReceiptNumber() {
  const directoryPath = path.join(__dirname, 'public', 'receipts');
  const files = fs.readdirSync(directoryPath);
  const receiptFiles = files.filter(file => file.startsWith('receipt(') && file.endsWith(').html'));
  return receiptFiles.length + 1;
}


app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});