const fs = require('fs');
const path = require('path');

function generateBookPageContent(book) {
    // Ensure the path is correct based on your project structure
    const templatePath = path.join(__dirname, '..', 'templates', 'bookTemplate.html');
    let template;

    try {
        template = fs.readFileSync(templatePath, 'utf8');
    } catch (err) {
        console.error(`Failed to read the template at ${templatePath}:`, err);
        return ''; // Return an empty string or a default error page content in case of error
    }

    // Use global replacement for placeholders
    let content = template
        .replace(/{{bookTitle}}/g, book.title)
        .replace(/{{bookAuthor}}/g, book.author)
        .replace(/{{bookPrice}}/g, book.price.toString())
        .replace(/{{bookDescription}}/g, book.description || 'No description available.');

    return content;
}

function saveBookPageToFile(book) {
    // Create a sanitized filename; consider using book.id for uniqueness
    const filename = `${book.id}-${book.title.replace(/[^a-zA-Z0-9]/g, '_')}.html`;
    const filePath = path.join(__dirname, '..', 'public', 'books', filename);
    const content = generateBookPageContent(book);

    try {
        if (!fs.existsSync(path.dirname(filePath))) {
            fs.mkdirSync(path.dirname(filePath), { recursive: true });
        }
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Page generated for ${book.title} at ${filePath}`);
    } catch (err) {
        console.error(`Failed to save the page for ${book.title}:`, err);
    }
}

module.exports = { saveBookPageToFile };
