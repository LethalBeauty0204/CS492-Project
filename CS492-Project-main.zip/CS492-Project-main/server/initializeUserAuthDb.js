const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcrypt');

// Specify the path for the new database
const dbPath = path.join(__dirname, '..', 'userAuth.db');

// Create and open the database
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        return console.error(err.message);
    }
    console.log('Connected to the userAuth.db SQLite database.');
});

// Create a users table
db.run(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        hashedPassword TEXT NOT NULL,
        passwordChangeDate TEXT NOT NULL
    )
`, (err) => {
    if (err) {
        console.error(err.message);
    } else {
        console.log('Created the users table in userAuth.db successfully.');
    }
});

// Optional admin user for testing
const insertAdminUser = (username, password) => {
    const saltRounds = 10;
    bcrypt.hash(password, saltRounds, (err, hashedPassword) => {
        if (err) {
            console.error('Error hashing password:', err);
            return;
        }
        db.run('INSERT INTO users (username, hashedPassword, passwordChangeDate) VALUES (?, ?, datetime("now"))', [username, hashedPassword], (err) => {
            if (err) {
                console.error('Error inserting admin user:', err.message);
            } else {
                console.log('Admin user inserted successfully.');
            }
        });
    });
};

// Adjust 'admin' and 'admin'
insertAdminUser('admin', 'admin');

// Close the database connection
db.close((err) => {
    if (err) {
        console.error(err.message);
    }
    console.log('Closed the database connection.');
});
