const express = require('express');
const path = require('path'); // Required for path manipulation

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, '..', 'public')));

// Handle root URL by serving index.html explicitly
// This is optional as express.static should automatically serve index.html at the root path
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// No need for an explicit route for '/index.html' as express.static will handle it

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
