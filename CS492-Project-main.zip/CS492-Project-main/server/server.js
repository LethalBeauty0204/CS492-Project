const express = require('express');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const saltRounds = 10;
const { saveBookPageToFile } = require('./bookPageGenerator');
const { saveReceiptToFile } = require('./receiptPageGenerator');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

const dbPath = path.join(__dirname, '..', 'mydb.db');
const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, dbErrorHandling);
const userAuthDbPath = path.join(__dirname, '..', 'userAuth.db');
const userAuthDb = new sqlite3.Database(userAuthDbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, dbErrorHandling);

function dbErrorHandling(err) {
    if (err) console.error('Database error:', err.message);
}

db.run('CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, price REAL)');
userAuthDb.run('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, hashedPassword TEXT, passwordChangeDate TEXT)');
initializeAdmin();

app.get('/books/:id', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'books', `${req.params.id}.html`));
});

app.post('/add-book', (req, res) => {
    const { title, author, price, description = '' } = req.body;
    db.run('INSERT INTO books (title, author, price, description) VALUES (?, ?, ?, ?)', [title, author, price, description], function(err) {
        if (err) return res.status(500).send(err.message);
        saveBookPageToFile({ id: this.lastID, title, author, price, description });
        res.json({ id: this.lastID });
    });
});

app.get('/books', (req, res) => {
    db.all("SELECT * FROM books", [], (err, rows) => {
        if (err) return res.status(500).send(err.message);
        res.json(rows);
    });
});

app.delete('/delete-book/:id', (req, res) => {
    db.run('DELETE FROM books WHERE id = ?', [req.params.id], function(err) {
        if (err) return res.status(500).send(err.message);
        res.json({ success: true, message: 'Book deleted successfully' });
    });
});

app.post('/update-book/:id', (req, res) => {
    const { title, author, price, description } = req.body;
    db.run('UPDATE books SET title = ?, author = ?, price = ?, description = ? WHERE id = ?', [title, author, price, description, req.params.id], function(err) {
        if (err) return res.status(500).send(err.message);
        db.get('SELECT * FROM books WHERE id = ?', [req.params.id], (err, book) => {
            if (err) return res.status(500).send(err.message);
            saveBookPageToFile(book);
            res.json({ message: 'Book updated successfully', data: book });
        });
    });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    userAuthDb.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
        if (err || !user) return res.status(401).send('Authentication failed.');
        bcrypt.compare(password, user.hashedPassword, (err, result) => {
            if (result) res.json({ message: "Login successful" });
            else res.status(401).send('Authentication failed.');
        });
    });
});

app.post('/change-password', async (req, res) => {
    const { username, newPassword } = req.body;
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
    userAuthDb.run('UPDATE users SET hashedPassword = ?, passwordChangeDate = datetime(\'now\') WHERE username = ?', [hashedPassword, username], function(err) {
        if (err) return res.status(500).send('Error updating password.');
        if (this.changes > 0) res.send('Password updated successfully.');
        else res.status(404).send('User not found.');
    });
});

app.post('/create-receipt', (req, res) => {
    const receiptData = req.body;
    saveReceiptToFile(receiptData, (err, filePath) => {
        if (err) return res.status(500).send('Failed to create receipt.');
        const filename = path.basename(filePath);
        res.redirect(`/receipts/${filename}`);
    });
});

function initializeAdmin() {
    bcrypt.hash('admin', saltRounds, (err, hash) => {
        if (err) console.error('Error hashing password:', err);
        userAuthDb.run('INSERT OR IGNORE INTO users (username, hashedPassword, passwordChangeDate) VALUES (?, ?, datetime(\'now\'))', ['admin', hash]);
    });
}

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
