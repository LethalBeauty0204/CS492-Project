const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, '..', 'public')));

// Initialize database
const dbPath = path.join(__dirname, '..', 'mydb.db');
const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
  if (err) {
    console.error('Error opening database', err.message);
  } else {
    // Removed imagePath from the table schema
    db.run('CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, price REAL)',
      (err) => {
        if (err) {
          console.error('Error creating table', err.message);
        }
      });
  }
});

// Add book endpoint without image upload
app.post('/add-book', (req, res) => {
  const { title, author, price } = req.body;
  db.run(`INSERT INTO books (title, author, price) VALUES (?, ?, ?)`, [title, author, price], function(err) {
    if (err) {
      res.status(500).send(err.message);
    } else {
      res.json({ id: this.lastID });
    }
  });
});

// Fetch all books endpoint
app.get('/books', (req, res) => {
  db.all("SELECT * FROM books", [], (err, rows) => {
    if (err) {
      res.status(500).send(err.message);
    } else {
      res.json(rows);
    }
  });
});

// Delete book endpoint
app.delete('/delete-book/:id', (req, res) => {
  const { id } = req.params;
  db.run(`DELETE FROM books WHERE id = ?`, id, function(err) {
    if (err) {
      res.status(500).send(err.message);
    } else {
      res.json({ success: true, message: `Book with ID ${id} deleted` });
    }
  });
});

// Update book endpoint without image handling
app.post('/update-book/:id', (req, res) => {
  const { id } = req.params;
  const { title, author, price } = req.body;
  
  // Simplified update without imagePath
  db.run(`UPDATE books SET title = ?, author = ?, price = ? WHERE id = ?`, [title, author, price, id], function(err) {
    if (err) {
      res.status(500).send(err.message);
    } else {
      res.json({ success: true, message: `Book with ID ${id} updated` });
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
