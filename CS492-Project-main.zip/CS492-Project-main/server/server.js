const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const { saveBookPageToFile } = require('./bookPageGenerator'); // Ensure this utility is correctly implemented

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Initialize database
const dbPath = path.join(__dirname, '..', 'mydb.db');
const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
  if (err) {
    console.error('Error opening database', err.message);
  } else {
    db.run('CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, price REAL)',
      (err) => {
        if (err) {
          console.error('Error creating table', err.message);
        }
      });
  }
});

// Serve individual book pages
app.get('/books/:id', (req, res) => {
  const bookId = req.params.id;
  res.sendFile(path.join(__dirname, '..', 'public', 'books', `${bookId}.html`));
});

// add-book endpoint w/ file creation
app.post('/add-book', (req, res) => {
  const { title, author, price, description = '' } = req.body; // Assume description might be optional
  db.run(`INSERT INTO books (title, author, price, description) VALUES (?, ?, ?, ?)`, [title, author, price, description], function(err) {
    if (err) {
      res.status(500).send(err.message);
    } else {
      const book = { id: this.lastID, title, author, price, description };
      saveBookPageToFile(book); // Now correctly passes a book object
      res.json({ id: this.lastID });
    }
  });
});



// Fetch all books endpoint
app.get('/books', (req, res) => {
  db.all("SELECT * FROM books", [], (err, rows) => {
    if (err) {
      res.status(500).send(err.message);
    } else {
      res.json(rows);
    }
  });
});

// Delete book endpoint
app.delete('/delete-book/:id', (req, res) => {
  const { id } = req.params;
  db.run(`DELETE FROM books WHERE id = ?`, id, function(err) {
    if (err) {
      res.status(500).send(err.message);
    } else {
      res.json({ success: true, message: `Book with ID ${id} deleted` });
    }
  });
});

app.post('/update-book/:id', (req, res) => {
  const { id } = req.params;
  const { title, author, price, description } = req.body;
  
  const sql = `UPDATE books SET title = ?, author = ?, price = ?, description = ? WHERE id = ?`;
  const params = [title, author, price, description, id];
  
  db.run(sql, params, function(err) {
      if (err) {
          res.status(500).send({error: err.message});
          return;
      }

      // Fetch the updated book details to ensure we have the latest information
      db.get(`SELECT * FROM books WHERE id = ?`, [id], (err, book) => {
          if (err) {
              res.status(500).send({error: err.message});
              return;
          }
          if (book.description) { // Check if the book has a description after fetching updated data
              saveBookPageToFile(book); // This function now expects a complete book object
          }
          res.json({
              message: "Success",
              data: book, // Send back the updated book data
              changes: this.changes
          });
      });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});