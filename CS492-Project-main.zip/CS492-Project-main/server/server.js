const express = require('express');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const saltRounds = 10;
const { saveBookPageToFile } = require('./bookPageGenerator');
const { saveReceiptToFile } = require('./receiptPageGenerator');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

const dbPath = path.join(__dirname, '..', 'mydb.db');
const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, dbErrorHandling);
const userAuthDbPath = path.join(__dirname, '..', 'userAuth.db');
const userAuthDb = new sqlite3.Database(userAuthDbPath, sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, dbErrorHandling);

function dbErrorHandling(err) {
    if (err) console.error('Database error:', err.message);
}

db.run('CREATE TABLE IF NOT EXISTS books (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, price REAL)');
userAuthDb.run('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, hashedPassword TEXT, passwordChangeDate TEXT)');
initializeAdmin();

app.get('/books/:id', (req, res) => {
    db.get("SELECT * FROM books WHERE id = ?", [req.params.id], (err, book) => {
        if (err) {
            console.error('Database error when fetching book:', err);
            return res.status(500).send({error: "Database access error"});
        }
        if (!book) {
            return res.status(404).send({error: "Book not found"});
        }
        const bookFilePath = path.join(__dirname, '..', 'public', 'books', `${book.title.replace(/ /g, '_')}.html`);
        res.sendFile(bookFilePath);
    });
});

app.post('/add-book', (req, res) => {
    const { title, author, price, description = '' } = req.body;
    db.run('INSERT INTO books (title, author, price, description) VALUES (?, ?, ?, ?)', [title, author, price, description], function(err) {
        if (err) return res.status(500).send(err.message);
        const bookDetails = { id: this.lastID, title, author, price, description };
        saveBookPageToFile(bookDetails);
        res.json({ id: this.lastID });
    });
});

app.get('/books', (req, res) => {
    db.all("SELECT * FROM books", [], (err, rows) => {
        if (err) return res.status(500).send(err.message);
        res.json(rows);
    });
});

app.delete('/delete-book/:id', (req, res) => {
    const bookId = req.params.id;
    db.get("SELECT * FROM books WHERE id = ?", [bookId], (err, book) => {
        if (err || !book) {
            console.error('Database error when fetching book for deletion:', err);
            return res.status(500).send({error: "Failed to fetch book for deletion"});
        }

        db.run('DELETE FROM books WHERE id = ?', [bookId], function(err) {
            if (err) {
                console.error('Database error when deleting book:', err);
                return res.status(500).send({error: "Error deleting book from database"});
            }

            const filePath = path.join(__dirname, '..', 'public', 'books', `${book.title.replace(/ /g, '_')}.html`);
            fs.unlink(filePath, err => {
                if (err) {
                    console.error("Failed to delete book file:", err);
                    return res.status(500).send({error: "Failed to delete book file"});
                }
                res.send({success: true, message: 'Book deleted successfully'});
            });
        });
    });
});

app.post('/update-book/:id', (req, res) => {
    const { title, author, price, description } = req.body;
    db.run('UPDATE books SET title = ?, author = ?, price = ?, description = ? WHERE id = ?', [title, author, price, description, req.params.id], function(err) {
        if (err) return res.status(500).send(err.message);
        db.get('SELECT * FROM books WHERE id = ?', [req.params.id], (err, book) => {
            if (err) return res.status(500).send(err.message);
            if (book) saveBookPageToFile(book);
            res.json({ message: 'Book updated successfully', data: book });
        });
    });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    userAuthDb.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
        if (err || !user) return res.status(401).send('Authentication failed.');
        bcrypt.compare(password, user.hashedPassword, (err, result) => {
            if (result) res.json({ message: "Login successful" });
            else res.status(401).send('Authentication failed.');
        });
    });
});

app.post('/change-password', async (req, res) => {
    const { username, newPassword } = req.body;
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
    userAuthDb.run('UPDATE users SET hashedPassword = ?, passwordChangeDate = datetime(\'now\') WHERE username = ?', [hashedPassword, username], function(err) {
        if (err) return res.status(500).send('Error updating password.');
        if (this.changes > 0) res.send('Password updated successfully.');
        else res.status(404).send('User not found.');
    });
});

app.post('/create-receipt', (req, res) => {
    const { items, bookIds, name, street, city, state, postalCode, email } = req.body;
    const receiptData = { items, name, street, city, state, postalCode, email };

    saveReceiptToFile(receiptData, (err, filePath) => {
        if (err) {
            console.error('Failed to create receipt:', err);
            return res.status(500).send('Failed to create receipt.');
        }

        const ids = JSON.parse(bookIds);
        const deletePromises = ids.map(id => {
            return new Promise((resolve, reject) => {
                db.get("SELECT * FROM books WHERE id = ?", [id], (err, book) => {
                    if (err) {
                        console.error('Database error when fetching book for deletion:', err);
                        reject(err);
                        return;
                    }

                    if (!book) {
                        console.error('Book not found:', id);
                        reject(new Error('Book not found'));
                        return;
                    }

                    db.run("DELETE FROM books WHERE id = ?", [id], (err) => {
                        if (err) {
                            console.error('Database error when deleting book:', err);
                            reject(err);
                            return;
                        }

                        const filePath = path.join(__dirname, '..', 'public', 'books', `${book.title.replace(/ /g, '_')}.html`);
                        fs.unlink(filePath, (err) => {
                            if (err) {
                                console.error("Failed to delete book file:", err);
                                reject(err);
                                return;
                            }
                            resolve();
                        });
                    });
                });
            });
        });

        Promise.all(deletePromises)
            .then(() => {
                const filename = path.basename(filePath);
                res.redirect(`/receipts/${filename}`);
            })
            .catch(err => {
                console.error('Failed to delete one or more books:', err);
                res.status(500).send('Failed to delete one or more books.');
            });
    });
});

app.get('/sales-data', (req, res) => {
    const year = parseInt(req.query.year);
    const month = parseInt(req.query.month);
    const directoryPath = path.join(__dirname, '..', 'public', 'receipts');

    fs.readdir(directoryPath, (err, files) => {
        if (err) {
            console.log('Error reading receipts directory:', err);
            return res.status(500).send('Failed to read receipts directory');
        }

        let monthlyCount = 0;
        let yearlyCount = 0;
        files.forEach(file => {
            const filePath = path.join(directoryPath, file);
            fs.stat(filePath, (err, stats) => {
                if (err) {
                    console.log('Error reading file stats:', err);
                    return;
                }

                const fileDate = new Date(stats.mtime);
                if (fileDate.getFullYear() === year) {
                    yearlyCount++;
                    if ((fileDate.getMonth() + 1) === month) {
                        monthlyCount++;
                    }
                }

                if (files.indexOf(file) === files.length - 1) {
                    res.json({ monthly: monthlyCount, yearly: yearlyCount });
                }
            });
        });
    });
});

app.get('/get-sales-data', (req, res) => {
    const { year, month } = req.query; // Ensure you're correctly parsing these as integers if necessary
    const targetDir = path.join(__dirname, '..', 'public', 'receipts');

    fs.readdir(targetDir, (err, files) => {
        if (err) {
            console.error('Error reading directory:', err);
            return res.status(500).send('Failed to read receipts directory.');
        }

        let monthlySales = 0;
        let yearlySales = 0;

        files.forEach(file => {
            const filePath = path.join(targetDir, file);
            fs.stat(filePath, (err, stats) => {
                if (err) {
                    console.error('Error reading file stats:', err);
                    return;
                }

                const fileDate = new Date(stats.mtime);
                const fileMonth = fileDate.getMonth() + 1;
                const fileYear = fileDate.getFullYear();

                if (fileYear === parseInt(year)) {
                    yearlySales++;
                    if (fileMonth === parseInt(month)) {
                        monthlySales++;
                    }
                }
            });
        });

        // Delay the response slightly to allow all filesystem checks to complete
        setTimeout(() => {
            res.json({ monthlySales, yearlySales });
        }, 100);
    });
});

app.get('/list-receipts', (req, res) => {
    const receiptsDir = path.join(__dirname, '..', 'public', 'receipts');
    fs.readdir(receiptsDir, (err, files) => {
        if (err) {
            console.error('Failed to read receipts directory:', err);
            return res.status(500).send('Failed to list receipts');
        }
        res.json(files);
    });
});

function initializeAdmin() {
    bcrypt.hash('admin', saltRounds, (err, hash) => {
        if (err) console.error('Error hashing password:', err);
        userAuthDb.run('INSERT OR IGNORE INTO users (username, hashedPassword, passwordChangeDate) VALUES (?, ?, datetime(\'now\'))', ['admin', hash]);
    });
}

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
