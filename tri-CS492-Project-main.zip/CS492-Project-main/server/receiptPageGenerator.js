const fs = require('fs');
const path = require('path');

function saveReceiptToFile(receiptData, callback) {
    const templatePath = path.join(__dirname, '..', 'templates', 'receiptTemplate.html');
    const receiptDirectory = path.join(__dirname, '..', 'public', 'receipts');
    const receiptNumber = getNextReceiptNumber(receiptDirectory);
    const receiptFilePath = path.join(receiptDirectory, `receipt(${receiptNumber}).html`);

    fs.readFile(templatePath, 'utf8', (err, template) => {
        if (err) {
            console.error('Error reading receipt template:', err);
            return callback(err, null);
        }

        let receiptContent = template
            .replace('{{itemsPlaceholder}}', receiptData.items)
            .replace('{{namePlaceholder}}', receiptData.name)
            .replace('{{streetPlaceholder}}', receiptData.street)
            .replace('{{cityPlaceholder}}', receiptData.city)
            .replace('{{statePlaceholder}}', receiptData.state)
            .replace('{{postalPlaceholder}}', receiptData.postalCode)
            .replace('{{emailPlaceholder}}', receiptData.email);

        fs.writeFile(receiptFilePath, receiptContent, 'utf8', (err) => {
            if (err) {
                console.error('Failed to write receipt file:', err);
                return callback(err, null);
            }
            console.log(`Receipt(${receiptNumber}) has been saved successfully.`);
            callback(null, receiptFilePath);  // Provide the path to the saved file as part of the callback
        });
    });
}

function getNextReceiptNumber(directoryPath) {
    // Synchronize directory reading to simplify receipt number calculation
    if (!fs.existsSync(directoryPath)){
        fs.mkdirSync(directoryPath, { recursive: true });  // Ensure the directory exists
    }
    const files = fs.readdirSync(directoryPath);
    const receiptFiles = files.filter(file => file.startsWith('receipt(') && file.endsWith(').html'));
    return receiptFiles.length + 1;
}

module.exports = { saveReceiptToFile };
